# Numeric Order Reference

Generate order references composed of nine random numbers instead of uppercase letters


Made by Brand New srl (http://brandnew.sm)
