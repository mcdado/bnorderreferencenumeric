<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{bnorderreferencenumeric}prestashop>bnorderreferencenumeric_c2004ad0437de669156fbd0d7f3b3e30'] = 'Riferimenti ordine numerici';
$_MODULE['<{bnorderreferencenumeric}prestashop>bnorderreferencenumeric_54b5eccc0f9b5820367cb10efcf6bc4f'] = 'Genera riferimenti ordine composti da nove cifre casuali invece che lettere maiuscole.';
