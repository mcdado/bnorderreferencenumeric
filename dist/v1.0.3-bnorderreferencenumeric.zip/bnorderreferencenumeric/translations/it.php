<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{bnorderreferencenumeric}prestashop>bnorderreferencenumeric_f20972eae641a1fcc374e73a6766c5e9'] = 'Riferimenti ordine numerici';
$_MODULE['<{bnorderreferencenumeric}prestashop>bnorderreferencenumeric_de5353d7669f9c60c8dc990ff207b35c'] = 'Genera riferimenti ordine composti da nove cifre casuali invece che lettere maiuscole.';
